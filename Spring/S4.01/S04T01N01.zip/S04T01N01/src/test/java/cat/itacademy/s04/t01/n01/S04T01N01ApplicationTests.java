package cat.itacademy.s04.t01.n01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T01N01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
